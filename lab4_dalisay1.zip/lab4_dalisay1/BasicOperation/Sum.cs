﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperation
{
    class Sum
    {
        public Sum()
            {
            DeclareVar var = new DeclareVar();
            Console.WriteLine(var);
            DeclareVar.sum= DeclareVar.num1 + DeclareVar.num2;
            Console.ReadLine();
        }
    }
}
